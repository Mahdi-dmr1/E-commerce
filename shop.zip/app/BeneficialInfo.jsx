export default function BeneficialInfo({ beneficialInfo }) {
	return (
		<div className="bg-white shadow-lg rounded-lg p-2 mb-2 ">
			<h1 className="text-center text-lg mb-2">مطالب مفید</h1>
			<hr />

			{beneficialInfo.map((data, key) => (
				<div className="grid grid-cols-5" key={key}>
					<img
						src={data.image}
						className="flex justify-start rounded-full w-20 h-20 col-span-2 "
					/>
					<h1 className=" text-gray-500 text-sm items-center flex justify-end col-span-3">
						{data.title}
					</h1>
				</div>
			))}
		</div>
	);
}
